
$(document).ready(function () {

  //initializing tooltip
  $('[data-toggle="tooltip"]').tooltip();

});

$(".fun-fact-btn").on("click", function(e){console.log(e)})